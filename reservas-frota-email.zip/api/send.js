// /api/send.js
// Função serverless da Vercel para envio de e-mail via Microsoft 365 (SMTP).
// Requer as variáveis de ambiente: M365_USER e M365_PASS.
const nodemailer = require("nodemailer");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method not allowed" });
    return;
  }
  const { to, subject, html } = req.body || {};
  if (!to) {
    res.status(400).json({ ok: false, error: "Missing 'to' address" });
    return;
  }

  const user = process.env.M365_USER;
  const pass = process.env.M365_PASS;
  if (!user || !pass) {
    res.status(500).json({ ok: false, error: "Missing SMTP credentials" });
    return;
  }

  // Config Microsoft 365 / Exchange Online
  const transporter = nodemailer.createTransport({
    host: "smtp.office365.com",
    port: 587,
    secure: false, // STARTTLS
    auth: { user, pass },
    tls: { ciphers: "SSLv3" },
  });

  try {
    await transporter.sendMail({
      from: `"Reservas Frota" <${user}>`,
      to,
      subject: subject || "Confirmação de reserva — Frota",
      html: html || "<p>Reserva criada com sucesso.</p>",
    });
    res.status(200).json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
};
